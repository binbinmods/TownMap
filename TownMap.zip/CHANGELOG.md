# 1.0.1

Fixed issue with Essentials soft dependency

# 1.0.0

Initial release.
